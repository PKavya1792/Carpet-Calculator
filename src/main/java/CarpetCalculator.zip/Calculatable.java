public interface Calculatable {
       void addRoom(Room room);
       String getTotalCost();
       void addPercentDiscount(float i);

  }



